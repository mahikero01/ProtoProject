"use strict";
var IfObservable_1 = require('./IfObservable');
exports._if = IfObservable_1.IfObservable.create;
//# sourceMappingURL=if.js.map