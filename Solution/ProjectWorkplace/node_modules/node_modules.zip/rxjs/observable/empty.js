"use strict";
var EmptyObservable_1 = require('./EmptyObservable');
exports.empty = EmptyObservable_1.EmptyObservable.create;
//# sourceMappingURL=empty.js.map