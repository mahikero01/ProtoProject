"use strict";
var PromiseObservable_1 = require('./PromiseObservable');
exports.fromPromise = PromiseObservable_1.PromiseObservable.create;
//# sourceMappingURL=fromPromise.js.map